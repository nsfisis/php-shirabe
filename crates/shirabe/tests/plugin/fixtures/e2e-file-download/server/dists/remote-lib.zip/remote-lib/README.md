Fixture package served by the E2E HTTP server.
